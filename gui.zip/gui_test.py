from tkinter import filedialog
from tkinter.scrolledtext import ScrolledText
from tkinter import *
import tkinter.ttk as ttk

from gui_train import GUITrainer
from gui_convert import GUIConverter

# Page for Training
class FrameTraining(Frame):

    def __init__(self, master):
        Frame.__init__(self, master)

        # Frame for Input Datasets
        self.frame_in = Frame(self)

        self.frame1 = Frame(self.frame_in, width=400, height=200)
        self.label1 = Label(self.frame1, text='Training Data Input', pady=5, anchor=W, font=('Times', 15))
        self.label1.grid(row=0, column=0, sticky=W)
        self.frame1.pack(anchor=W)
        # Frame for Input Paths
        self.frame2 = Frame(self.frame_in, width=400, height=200)

        # Training Data A
        self.frame_A = Frame(self.frame2)
        self.label_A = Label(self.frame_A, text='Training Data A')
        self.label_A.grid(row=0, column=0, sticky=W)
        self.box_A = Entry(self.frame_A, width=65)
        self.box_A.grid(row=1, column=0)
        self.blank_A = Canvas(self.frame_A, height=1, width=3)
        self.blank_A.grid(row=1, column=1)
        self.button_A = Button(self.frame_A, text='Browse', bg='lawn green',
                               fg='white', command=lambda: self.askpath(self.box_A))
        self.button_A.grid(row=1, column=2)
        self.frame_A.pack()

        # Training Data B
        self.frame_B = Frame(self.frame2)

        self.label_B = Label(self.frame_B, text='Training Data B')
        self.label_B.grid(row=0, column=0, sticky=W)
        self.box_B = Entry(self.frame_B, width=65)
        self.box_B.grid(row=2, column=0)
        self.blank_B = Canvas(self.frame_B, height=1, width=3)
        self.blank_B.grid(row=1, column=1)
        self.button_B = Button(self.frame_B, text='Browse', bg='lawn green',
                               fg='white', command=lambda: self.askpath(self.box_B))
        self.button_B.grid(row=2, column=2)
        self.frame_B.pack()
        self.frame2.pack(anchor=W)
        self.frame_in.pack()

        # Frame for Pre-Trained Parameters Check Box
        self.frame_check = Frame(self)
        self.check = IntVar()
        self.check_box = Checkbutton(self.frame_check, text='Use Pre-Trained Parameters', variable=self.check)
        self.check_box.pack()
        self.frame_check.pack()

        # Frame for Start Training Button
        self.frame_st = Frame(self)
        self.botton_st = Button(self.frame_st, text='Start Training', padx=10,
                                command=lambda: self.start_train(self.box_A.get(),
                                                                 self.box_B.get(), self.train_status, self.check.get()))
        self.botton_st.pack()
        self.frame_st.pack()

        # Frame for Displaying Status
        self.frame_status = Frame(self, pady=5)
        self.train_status = ScrolledText(self.frame_status, height=5)
        self.train_status.pack()

        self.frame_status.pack()

    def askpath(self, entry):
        path = filedialog.askdirectory()
        if entry.get():
            entry.delete(0)
        entry.insert(0, path)

    def start_train(self, path_a, path_b, box, pre_train):
        print(f"path_a: {path_a}")
        print(f"path_b: {path_b}")
        print(f"box: {box}")
        print(f"pre_train: {pre_train}")
        self.trainer = GUITrainer(path_a, path_b, load_weights=pre_train)
        self.trainer.train()


# Page for Inference
class FrameInference(Frame):
    def __init__(self, master):
        Frame.__init__(self, master)

        # Frame for Inference Options
        self.frame_up = Frame(self)

        # Notebook Initialize
        self.note = ttk.Notebook(self.frame_up, width=600)
        # Frame for Local Files Inference
        self.frame1 = Frame(self.note, width=500)

        # Frame for Inputting Options
        self.frame_in = Frame(self.frame1)
        self.lab_input = Label(self.frame_in, text='Input File')
        self.lab_input.grid(row=0, column=0)
        self.box1 = Entry(self.frame_in, width=65)
        self.box1.grid(row=1, column=0)
        self.blank_A = Canvas(self.frame_in, height=1, width=3)
        self.blank_A.grid(row=1, column=1)
        self.button_in = Button(self.frame_in, text='Browse', bg='lawn green',
                                fg='white', command=lambda: self.askfile(self.box1))
        self.button_in.grid(row=1, column=2)
        self.frame_in.pack()

        # Frame for Outputting Options
        self.frame_out = Frame(self.frame1)
        self.lab_output = Label(self.frame_out, text='Output Path')
        self.lab_output.grid(row=0, column=0)
        self.box2 = Entry(self.frame_out, width=65)
        self.box2.grid(row=1, column=0)
        self.blank_B = Canvas(self.frame_out, height=1, width=3)
        self.blank_B.grid(row=1, column=1)
        self.button_in = Button(self.frame_out, text='Browse', bg='lawn green',
                                fg='white', command=lambda: self.askpath(self.box2))
        self.button_in.grid(row=1, column=2)
        self.frame_out.pack()

        # Frame for Character Options
        self.frame_radio_1 = Frame(self.frame1)
        self.chara_option_1 = IntVar()
        self.frame_radio_1.pack()
        self.option_A_1 = Radiobutton(self.frame_radio_1, text='Swapping A to B', value=0, variable=self.chara_option_1)
        self.option_A_1.pack()
        self.option_B_1 = Radiobutton(self.frame_radio_1, text='Swapping B to A', value=1, variable=self.chara_option_1)
        self.option_B_1.pack()

        # Frame for Check Box of Model Initialization
        self.frame_check_1 = Frame(self.frame1)
        # Variable for If Use Pre-Train Parameters
        self.check1 = IntVar()
        # Check Box
        self.check_box_1 = Checkbutton(self.frame_check_1, text='Use Pre-Trained Parameters', variable=self.check1)
        self.check_box_1.pack()
        self.frame_check_1.pack()

        # Frame for Local Inference Button
        self.frame_start_1 = Frame(self.frame1)
        self.start_button_1 = Button(self.frame_start_1, text='Start Swapping',
                                     command=lambda: self.start_infer(self.check1.get(), self.chara_option_1.get()))
        self.start_button_1.pack()
        self.frame_start_1.pack()

        # Frame for Real-Time Swapping
        self.frame2 = Frame(self.note, width=500)
        self.infer_label = Label(self.frame2, text='Real-Time Swapping', pady=5, anchor=W, font=('Times', 15))
        self.infer_label.pack()

        # Frame for Character Options
        self.frame_radio_2 = Frame(self.frame2)
        self.chara_option_2 = IntVar()
        self.frame_radio_2.pack()
        self.option_A_2 = Radiobutton(self.frame_radio_2, text='Swapping A to B', value=0, variable=self.chara_option_2)
        self.option_A_2.pack()
        self.option_B_2 = Radiobutton(self.frame_radio_2, text='Swapping B to A', value=1, variable=self.chara_option_2)
        self.option_B_2.pack()

        # Frame for Check Box of Model Initialization
        self.frame_check_2 = Frame(self.frame2)
        # Variable for If Use Pre-Train Parameters
        self.check2 = IntVar()
        # Check Box
        self.check_box_2 = Checkbutton(self.frame_check_2, text='Use Pre-Trained Parameters', variable=self.check2)
        self.check_box_2.pack()
        self.frame_check_2.pack()
        # Start Real-Time Swapping Button
        self.start_button_2 = Button(self.frame2, text='Start Swapping',
                                     command=lambda: self.start_realtime(self.check2.get(), self.chara_option_2.get()))
        self.start_button_2.pack()

        self.note.add(self.frame1, text='Local File')
        self.note.add(self.frame2, text='Real-Time Capture')
        self.note.pack()
        self.frame_up.pack()

        # Frame for Displaying Status
        self.frame_down = Frame(self)
        self.status_box = ScrolledText(self.frame_down, height=5)
        self.status_box.pack()
        self.frame_down.pack()

    def askfile(self, entry):
        path = filedialog.askopenfilename()
        if entry.get():
            entry.delete(0)
        entry.insert(0, path)

    def askpath(self, entry):
        path = filedialog.askdirectory()
        if entry.get():
            entry.delete(0)
        entry.insert(0, path)

    # Function for File Processing
    def start_infer(self, use_pre, chara_option):
        try:
            self.converter
        except:
            self.converter = GUIConverter(load_weights=use_pre)  
        if self.converter.input_file is None or self.converter.output_path is None:      
            self.converter.input_file = "INPUT_VIDEO.mp4"
            self.converter.output_path = "./"
        self.converter.convert(mode="offline")

    # Function for Real-Time Processing
    def start_realtime(self, use_pre, chara_option):
        try:
            self.converter
        except:            
            self.converter = GUIConverter(load_weights=use_pre)
        self.converter.convert(mode="realtime")


root = Tk()
root.title('FaceSwapping Master')
root.geometry('600x300')

frame_main = Frame()

note = ttk.Notebook(frame_main)
frame_train = FrameTraining(note)
frame_infer = FrameInference(note)

note.add(frame_train, text='Training')
note.add(frame_infer, text='Swapping')

note.pack()

frame_main.pack()

root.mainloop()






