import os
import cv2
import glob
import numpy as np
from pathlib import Path
import keras.backend as K
import tensorflow as tf

from utils import load_yaml
from networks.faceswap_gan_model import FaceswapGANModel
from detector.face_detector import MTCNNFaceDetector
from converter.video_converter import VideoConverter
from converter.color_correction import color_hist_match, adain
from converter.landmarks_alignment import get_src_landmarks, get_tar_landmarks, landmarks_match_mtcnn

# Global constants
MODEL_PATH = os.path.join("models")
CONFIGS_PATH = os.path.join("configs", "base_config.yaml")
VC_CONFIGS_PATH = os.path.join("configs", "conversion_config.yaml")

class GUIConverter(object):
    """    
    Arguments:
        input_file: A string. Path to the input video file.
        output_path: A string. 
        direction: A string. Either "AtoB" or "BtoA".
        load_weights: Boolean. Whether to load the pre-trained model.
        duration: Tuple (t_start, t_end). Start time and end time of the input clip.
        
    TODO:
        1. [GUI] Configurable input clip between times t_start and t_end.
        2. [GUI] (Real-time mode) Modify self.options["direction"] when radio button onchange is called
    """
    def __init__(self,
                 input_file=None, 
                 output_path=None, 
                 direction="AtoB",
                 load_weights=True,
                 duration=None):
        self.input_file = input_file
        self.output_path = output_path
        self.duration = duration
        
        # Clear current graph and release memory
        tf.reset_default_graph()
        K.clear_session()
        
        # Load experiment settings
        configs = load_yaml(CONFIGS_PATH)
        self.arch_config = configs["arch_config"]
        self.arch_config['IMAGE_SHAPE'] = (self.arch_config["resolution"], 
                                           self.arch_config["resolution"], 3)
        self.options = load_yaml(VC_CONFIGS_PATH)
        self.options["direction"] = direction
        self.options["IMAGE_SHAPE"] = self.arch_config['IMAGE_SHAPE']
        
        # Create model
        print("Creating model.")
        K.set_learning_phase(0)
        self.model = FaceswapGANModel(**self.arch_config)    

        # Load model weights
        if load_weights:
            print("Loading pre-trained model weights.")
            self.model.load_weights(path=MODEL_PATH)       
        
        # initialize face detector
        try: 
            self.fd
        except:
            print("Instantiating MTCNNFaceDetector.")
            self.fd = MTCNNFaceDetector(sess=K.get_session(), model_path="./mtcnn_weights/")
    
    def set_input_output(self, input_file, output_path):
        self.input_file = input_file
        self.output_path = output_path
    
    def convert(self, mode="offline"):
        """
        Execute face-swapping on the given input file.
        
        Arguments:
            mode: A string. Either "offline" or "realtime".
        """         
        # Set forward pass direction
        if self.options["direction"] == "AtoB":
            self.path_func = self.model.path_abgr_B
        elif self.options["direction"] == "BtoA":
            self.path_func = self.model.path_abgr_A
        else:
            raise ValueError(f"direction should be either AtoB or BtoA, recieved {direction}.")
            
        if mode == "offline":
            if self.input_file is None:
                print("Error: input_file is None.")
                raise Exception("input_file is None.")
            if self.output_path is None:
                print("Error: output_path is None.")
                raise Exception("output_path is None.")
                
            raw_fn = os.path.splitext(os.path.split(self.input_file)[-1])[-2]
            fn_ext = os.path.splitext(self.input_file)[-1]         
            output_fn = raw_fn + "_" + self.options["direction"] + fn_ext
            output_fn = os.path.join(self.output_path, output_fn)
            
            print("Start video conversion.")
            vc = VideoConverter()
            vc.set_face_detector(self.fd)
            vc.set_gan_model(self.model)
            vc.convert(input_fn=self.input_file, 
                       output_fn=output_fn, 
                       options=self.options, 
                       duration=self.duration)
            print("Video conversion completed.")
            
        elif mode == "realtime":
            """
            TODO:
                load_camera_frame(), something like:
                
                cap = cv2.VideoCapture(0)
                while True:
                    _, frame = cap.read()     
                    ....
            """    
            print("Start real time conversion.")
            frame = self.load_camera_frame() # expect frame image having format RGB.
            
            # Detect face
            list_faces, list_lms = self.fd.detect_face(frame)
            
            # loop through and convert each detected face
            for face, lms in zip(list_faces, list_lms.T):
                lms = lms[...,np.newaxis]
                x0, y1, x1, y0, _ = face
                sx = slice(int(x0),int(x1))
                sy = slice(int(y0),int(y1))
                det_face_im = frame[sx, sy,:]

                # align face
                src_landmarks = get_src_landmarks(x0, x1, y0, y1, lms)
                tar_landmarks = get_tar_landmarks(det_face_im)
                aligned_det_face_im = landmarks_match_mtcnn(det_face_im, src_landmarks, tar_landmarks)

                # Transform detected face
                result_img, result_mask = self.transform_face(aligned_det_face_im, 
                                                              roi_coef=self.options["roi_coef"], 
                                                              path_func=self.path_func, 
                                                              resolution=self.options["IMAGE_SHAPE"][0], 
                                                              color_correction="adain_xyz")
                
                # reverse face alignment
                result_img = landmarks_match_mtcnn(result_img, tar_landmarks, src_landmarks)
                result_mask = landmarks_match_mtcnn(result_mask, tar_landmarks, src_landmarks)

                # paste result image back to input frame
                try:
                    result_input_img
                except:
                    result_input_img = frame.copy()
                result_mask = result_mask.astype(np.float32)
                result_input_img[sx, sy, :] = result_mask/255 * result_img + (1-result_mask/255) * result_input_img[sx, sy, :]
                
            cv2.imshow("Frame", result_input_img)
            #return result_input_img
        
        else:
            raise ValueError(f"Recieved an unknown mode {mode}.")
    
    @staticmethod
    def transform_face(inp_img, roi_coef, path_func, resolution, color_correction):
        """
        Arguments:
            inp_img: A RGB face image of any size.
        Returns:
            result_img: A RGB swapped face image after masking.
            result_mask: The alpha mask which corresponds to the result_img.
        """  
        def get_feather_edges_mask(img, roi_coef, resolution):
            img_size = img.shape
            mask = np.zeros_like(img)
            x_, y_ = img_size[0]//roi_coef, img_size[1]//roi_coef
            mask[x_:-x_, y_:-y_,:]  = 255
            kernel_size = 15 * (resolution // 64)
            if not (kernel_size & 0x1): # if not is_odd
                kernel_size += 1
            mask = cv2.GaussianBlur(mask, (kernel_size,kernel_size), 10).astype(np.float32) / 255
            return mask  
        
        # pre-process input image
        img_bgr = cv2.cvtColor(inp_img, cv2.COLOR_RGB2BGR)
        input_size = img_bgr.shape    
        roi_x, roi_y = input_size[0]//roi_coef, input_size[1]//roi_coef
        roi = img_bgr[roi_x:-roi_x, roi_y:-roi_y,:] # BGR, [0, 255]  
        roi_size = roi.shape
        ae_input = cv2.resize(roi, (resolution, resolution)) / 255. * 2 - 1 # BGR, [-1, 1]       

        # forward pass
        ae_output = np.squeeze(np.array([path_func([[ae_input]])]))
        
        # post-process transformed roi image
        ae_output_a = ae_output[:,:,0] * 255
        ae_output_a = cv2.resize(ae_output_a, (roi_size[1],roi_size[0]))[...,np.newaxis]
        ae_output_bgr = np.clip( (ae_output[:,:,1:] + 1) * 255 / 2, 0, 255)
        ae_output_bgr = cv2.resize(ae_output_bgr, (roi_size[1],roi_size[0]))
        ae_output_masked = (ae_output_a/255 * ae_output_bgr + (1 - ae_output_a/255) * roi).astype('uint8') # BGR, [0, 255]
        
        # apply color correciton
        if color_correction == "adain":
            ae_output_masked = adain(ae_output_masked, roi)
        elif color_correction == "adain_xyz":
            ae_output_masked = adain(ae_output_masked, roi, color_space="XYZ")
        elif color_correction == "hist_match":
            ae_output_masked = color_hist_match(ae_output_masked, roi)

        # merge transformed output back to input image
        blend_mask = get_feather_edges_mask(roi, roi_coef, resolution)        
        blended_img = blend_mask * ae_output_masked + (1 - blend_mask) * roi
        result = img_bgr
        result[roi_x:-roi_x, roi_y:-roi_y,:] = blended_img 
        result = cv2.cvtColor(result, cv2.COLOR_BGR2RGB) 
        result_alpha = np.zeros_like(img_bgr)
        result_alpha[roi_x:-roi_x, roi_y:-roi_y,:] = blend_mask * ae_output_a 
        return result, result_alpha    
    
    def load_camera_frame(self):
        print("load_camera_frame() has not been implemented.")
        raise NotImplementedError("load_camera_frame() not implemented.")
            
            
            
            
            
            
            
            