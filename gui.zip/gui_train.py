import os
import cv2
import glob
import time
import numpy as np
from pathlib import Path
import keras.backend as K
import tensorflow as tf

from networks.faceswap_gan_model import FaceswapGANModel
from data_loader.data_loader import DataLoader
from utils import load_yaml, show_loss_config, save_preview_image
from keras_vggface.vggface import VGGFace
from detector.face_detector import MTCNNFaceDetector
from preprocess import preprocess_video

# Global constants
MODEL_PATH = os.path.join("models")
CONFIGS_PATH = os.path.join("configs", "base_config.yaml") 
    
class GUITrainer(object):
    """
    A class that will be instantiated when the start training buttom in the GUI is clicked.
    
    Arguments:
        path_datasetA: A string. Path to the folder holding the training dataset A.
        path_datasetB: A string. Path to the folder holding the training dataset B.
        load_weights: Boolean. Whether to load the pre-trained model.
        path_bm_datasetA: A string. Path to the folder holding the binary masks for dataset A.
        path_bm_datasetB: A string. Path to the folder holding the binary masks for dataset B.

    TODO:
        1. Add an option for using auxiliary binary mask of eyes.
        2. Add a extremely lite model for debugging and unit test.
        3. Add resume/continue training functionality.
    """
    def __init__(self, 
                 path_datasetA, 
                 path_datasetB, 
                 load_weights=False, 
                 path_bm_datasetA="non_existing_path", 
                 path_bm_datasetB="non_existing_path"):
        
        # Clear current graph and release memory
        tf.reset_default_graph()
        K.clear_session()
        
        # Load experiment settings
        configs = load_yaml(CONFIGS_PATH)
        self.arch_config = configs["arch_config"]
        self.loss_weights = configs["loss_weights"]
        self.loss_config = configs["loss_config"]
        self.da_config = configs["da_config"]
        self.display_iters = configs["display_iters"]
        self.backup_iters = configs["backup_iters"]
        self.total_iters = configs["total_iters"]
        self.batch_size = self.arch_config["batch_size"]
        self.arch_config['IMAGE_SHAPE'] = (self.arch_config["resolution"], 
                                           self.arch_config["resolution"], 3)

        # Get number of CPUs
        self.num_cpus = os.cpu_count()

        # Create model
        print("Creating model.")
        K.set_learning_phase(1)
        self.model = FaceswapGANModel(**self.arch_config)    

        # Load model weights
        if load_weights:
            print("Loading pre-trained model weights.")
            self.model.load_weights(path=MODEL_PATH)

        # Setup loss functions
        print("Setting-up model.")
        self.vggface = VGGFace(include_top=False, model="resnet50", input_shape=(224, 224, 3))
        self.model.build_pl_model(vggface_model=self.vggface, before_activ=self.loss_config["PL_before_activ"])
        self.model.build_train_functions(loss_weights=self.loss_weights, **self.loss_config)

        # Create save directory
        Path(MODEL_PATH).mkdir(parents=True, exist_ok=True)

        # Get training data
        self._get_training_data(path_datasetA, path_datasetB, path_bm_datasetA, path_bm_datasetB)
        
    def _get_training_data(self, path_datasetA, path_datasetB, path_bm_datasetA, path_bm_datasetB):
        print(f" ========== Processing {path_datasetA} folder ==========")
        self.train_A = self._preprocess_dataset(path_datasetA)
        if len(self.train_A) == 0:
            raise Exception(f"Error: no training data found in {path_datasetA}.")
        else:
            len_dataset = len(self.train_A)
            print(f"Folder {path_datasetA} has {len_dataset} training image(s).")
        print(f" ========== Processing {path_datasetB} folder ==========")
        self.train_B = self._preprocess_dataset(path_datasetB)
        if len(self.train_B) == 0:
            raise Exception(f"Error: no training data found in {path_datasetB}.")
        else:
            len_dataset = len(self.train_B)
            print(f"Folder {path_datasetB} has {len_dataset} training image(s).")
        self.train_AnB = self.train_A + self.train_B
        self.img_dirA_bm_eyes = path_bm_datasetA # os.path.join(path_datasetA, "*", "binary_mask")
        self.img_dirB_bm_eyes = path_bm_datasetB # os.path.join(path_datasetB, "*", "binary_mask")
        
        
    def _preprocess_dataset(self, path_dataset, save_video_frame_interval=6):
        """
        Retrieve image filenames and preprocess video file(s) if necessary.
        
        Arguments:
            path_dataset: A string. Path to the dataset folder.
            save_video_frame_interval: An integer. Face detection interval for video processing.
        
        Returns:
            trn_fns: A list. File names of the training images after preprocessing.
        """
        img_fns, vid_fns = self._analyze_dataset(path_dataset)
        num_vids = len(vid_fns)
        if num_vids > 0:
            print(f"Found {num_vids} video(s) in {path_dataset} folder.")
            fd = self._get_face_detector()
            for i, fn in enumerate(vid_fns):
                raw_fn = os.path.splitext(os.path.split(fn)[-1])[-2]
                save_path = os.path.join(path_dataset, f"{raw_fn}")  
                print(f"Processing video: {raw_fn}.")              
                preprocess_video(fn, 
                                 fd, 
                                 save_interval=save_video_frame_interval, 
                                 save_path=save_path)
        detected_face_img_fns = glob.glob(os.path.join(path_dataset, "*", "rgb", "*.jpg"))
        num_detected_face_imgs = len(detected_face_img_fns)
        if num_detected_face_imgs > 0:
            print(f"{num_detected_face_imgs} detected face(s) \
            are added into {path_dataset} folder as training data.")
        trn_fns = img_fns + detected_face_img_fns
        return trn_fns
    
    @staticmethod
    def _analyze_dataset(path_dataset):
        """
        Identify data type of files inside the given folder.
        
        Arguments:
            path_dataset: A string. Path to the dataset folder.
            
        Returns:
            img_fns: A list. File names of JPG and PNG images files
            vid_fns: A list. File names of MP4 and AVI video files.
        
        """
        img_fns = glob.glob(os.path.join(path_dataset, "*.jpg"))
        img_fns += glob.glob(os.path.join(path_dataset, "*.png"))
        vid_fns = glob.glob(os.path.join(path_dataset, "*.mp4"))
        vid_fns += glob.glob(os.path.join(path_dataset, "*.avi"))
        return img_fns, vid_fns
        
    def _get_face_detector(self):
        try:
            self.fd
        except:
            print("Instantiating MTCNNFaceDetector.")
            self.fd = MTCNNFaceDetector(sess=K.get_session(), model_path="./mtcnn_weights/")
        return self.fd
    
    def train(self):
        print("Start training.")
        t0 = time.time()
        
        # This try/except is meant to resume training that was accidentally interrupted
        try:
            self.gen_iterations
            print(f"Resume training from iter {self.gen_iterations}.")
        except:
            self.gen_iterations = 0

        # Initialize error logger
        errGA_sum = errGB_sum = errDA_sum = errDB_sum = 0
        errGAs = {}
        errGBs = {}        
        for k in ['ttl', 'adv', 'recon', 'edge', 'pl']:
            # Dictionaries are ordered in Python 3.6
            errGAs[k] = 0
            errGBs[k] = 0        

        # Instantiate data generators
        self.create_dataloader()

        while self.gen_iterations <= self.total_iters: 
            # Loss function automation
            if self.gen_iterations == (self.total_iters//5 - self.display_iters//2):
                self.loss_automation(phase=1)
            elif self.gen_iterations == (self.total_iters//5 + self.total_iters//10 - self.display_iters//2):
                self.loss_automation(phase=2)
            elif self.gen_iterations == (2*self.total_iters//5 - self.display_iters//2):
                self.loss_automation(phase=3)
            elif self.gen_iterations == (self.total_iters//2 - self.display_iters//2):
                self.loss_automation(phase=4)
            elif self.gen_iterations == (2*self.total_iters//3 - self.display_iters//2):
                self.loss_automation(phase=5)
            elif self.gen_iterations == (8*self.total_iters//10 - self.display_iters//2):
                self.loss_automation(phase=6)
            elif self.gen_iterations == (9*self.total_iters//10 - self.display_iters//2):
                self.loss_automation(phase=7)

            # Train dicriminators for one batch
            data_A = self.train_batchA.get_next_batch()
            data_B = self.train_batchB.get_next_batch()
            errDA, errDB = self.model.train_one_batch_D(data_A=data_A, data_B=data_B)

            # Train generators for one batch
            data_A = self.train_batchA.get_next_batch()
            data_B = self.train_batchB.get_next_batch()
            errGA, errGB = self.model.train_one_batch_G(data_A=data_A, data_B=data_B)            
            self.gen_iterations += 1

            # Update errors
            errDA_sum +=errDA[0]
            errDB_sum +=errDB[0]
            errGA_sum += errGA[0]
            errGB_sum += errGB[0]
            for i, k in enumerate(['ttl', 'adv', 'recon', 'edge', 'pl']):
                errGAs[k] += errGA[i]
                errGBs[k] += errGB[i]

            # Visualization
            if self.gen_iterations % self.display_iters == 0 or self.gen_iterations == 1:
                """
                TODO: Clear screen before printing out curren loss.
                """

                # Display loss information
                show_loss_config(self.loss_config)            
                print("----------") 
                print('[iter %d] Loss_DA: %f Loss_DB: %f Loss_GA: %f Loss_GB: %f time: %f'
                % (self.gen_iterations, errDA_sum/self.display_iters, errDB_sum/self.display_iters,
                   errGA_sum/self.display_iters, errGB_sum/self.display_iters, time.time()-t0))  
                print("----------") 
                print("Generator loss details:")
                print(f'[Adversarial loss]')  
                print(f'GA: {errGAs["adv"]/self.display_iters:.4f} \
                GB: {errGBs["adv"]/self.display_iters:.4f}')
                print(f'[Reconstruction loss]')
                print(f'GA: {errGAs["recon"]/self.display_iters:.4f} \
                GB: {errGBs["recon"]/self.display_iters:.4f}')
                print(f'[Edge loss]')
                print(f'GA: {errGAs["edge"]/self.display_iters:.4f} \
                GB: {errGBs["edge"]/self.display_iters:.4f}')
                if self.loss_config['use_PL'] == True:
                    print(f'[Perceptual loss]')
                    try:
                        print(f'GA: {errGAs["pl"][0]/self.display_iters:.4f} \
                        GB: {errGBs["pl"][0]/self.display_iters:.4f}')
                    except:
                        print(f'GA: {errGAs["pl"]/self.display_iters:.4f} \
                        GB: {errGBs["pl"]/self.display_iters:.4f}')

                # Save preview images
                print("Saving the preview image as ./preview.jpg ") 
                _, tA, _ = self.train_batchA.get_next_batch()
                _, tB, _ = self.train_batchB.get_next_batch()
                save_preview_image(tA, tB, 
                                   self.model.path_A, 
                                   self.model.path_B, 
                                   self.model.path_bgr_A, 
                                   self.model.path_bgr_B,                               
                                   self.model.path_mask_A, 
                                   self.model.path_mask_B, 
                                   self.batch_size, 
                                   save_fn="preview.jpg")

                # Save models
                print(f"Saving the latest model to {MODEL_PATH}.")
                self.model.save_weights(path=MODEL_PATH)

                # Clear erros
                errGA_sum = errGB_sum = errDA_sum = errDB_sum = 0
                for k in ['ttl', 'adv', 'recon', 'edge', 'pl']:
                    errGAs[k] = 0
                    errGBs[k] = 0

            # Backup models
            if self.gen_iterations % self.backup_iters == 0: 
                bkup_dir = os.path.join(f"{MODEL_PATH}", f"backup_iter{self.gen_iterations}")
                Path(bkup_dir).mkdir(parents=True, exist_ok=True)
                self.model.save_weights(path=bkup_dir)
    
    def create_dataloader(self):        
        self.train_batchA = DataLoader(self.train_A, 
                                       self.train_AnB, 
                                       self.batch_size, 
                                       self.img_dirA_bm_eyes,
                                       self.arch_config["resolution"], 
                                       self.num_cpus, 
                                       K.get_session(), 
                                       **self.da_config)
        self.train_batchB = DataLoader(self.train_B, 
                                       self.train_AnB, 
                                       self.batch_size, 
                                       self.img_dirB_bm_eyes, 
                                       self.arch_config["resolution"], 
                                       self.num_cpus, 
                                       K.get_session(), 
                                       **self.da_config)
    
    def loss_automation(self, phase=0):
        if phase == 1:
            self.loss_config['use_PL'] = True
            self.loss_config['use_mask_hinge_loss'] = False
            self.loss_config['m_mask'] = 0.0
        elif phase == 2:
            self.loss_config['use_PL'] = True
            self.loss_config['use_mask_hinge_loss'] = True
            self.loss_config['m_mask'] = 0.5
        elif phase == 3:
            self.loss_config['use_PL'] = True
            self.loss_config['use_mask_hinge_loss'] = True
            self.loss_config['m_mask'] = 0.2
        elif phase == 4:
            self.loss_config['use_PL'] = True
            self.loss_config['use_mask_hinge_loss'] = True
            self.loss_config['m_mask'] = 0.4
        elif phase == 5:
            self.loss_config['use_PL'] = True
            self.loss_config['use_mask_hinge_loss'] = False
            self.loss_config['m_mask'] = 0.
            self.loss_config['lr_factor'] = 0.3
        elif phase == 6:
            self.loss_config['use_PL'] = True
            self.loss_config['use_mask_hinge_loss'] = True
            self.loss_config['m_mask'] = 0.1
            self.loss_config['lr_factor'] = 0.3
            # swap decoders
            self.model.decoder_A.load_weights(f"{MODEL_PATH}/decoder_B.h5")
            self.model.decoder_B.load_weights(f"{MODEL_PATH}/decoder_A.h5")
        elif phase == 7:
            self.loss_config['use_PL'] = True
            self.loss_config['use_mask_hinge_loss'] = False
            self.loss_config['m_mask'] = 0.
            self.loss_config['lr_factor'] = 0.1
        else:
            raise ValueError(f"Recieved an unknown phase param.: {phase}.")
            
        try:
            self.gen_iterations
        except:
            self.gen_iterations = 0
        print(f"[iter {self.gen_iterations}] Building new loss funcitons:")
        print("----------") 
        show_loss_config(self.loss_config)
        self.reset_session()
        self.model.build_train_functions(self.loss_weights, **self.loss_config)
        print("----------") 
    
    def reset_session(self):
        """
        Reset current keras session. Models and data generators will be re-instantiate.
        This is to prevent OOM error when frequently re-building loss function.        
        """
        self.model.save_weights(MODEL_PATH)
        del self.model, self.vggface
        K.clear_session()
        self.model = FaceswapGANModel(**self.arch_config)
        self.model.load_weights(MODEL_PATH)
        self.vggface = VGGFace(include_top=False, model="resnet50", input_shape=(224, 224, 3))
        self.model.build_pl_model(vggface_model=self.vggface, 
                                  before_activ=self.loss_config["PL_before_activ"])
        self.create_dataloader()